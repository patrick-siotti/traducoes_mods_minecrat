# traducao-galacticraft
tradução do mod galacticraft para minecraft 1.12.2

se você for usar o mod do galacticraft, você vai ver que uma parte esta em português, e outra em inglês, e isso é estremamente chato, para isso, aqui esta a tradução desse mod

obs: a peça chamada "wafer" foi substituida por "peça".

# como usar a tradução:

baixe a tradução

extraia ela e abra a pasta extraida

copie o arquivo pt_BR

vá até o arquivo do mod, clique com o botão direito, ir té "abrir como", clicar em "winRar archive" ou só "WinRar"

abrir a pasta assets

abrir a pasta galacticraftcore

abrir a pasta lang

então colar o arquivo da tradução

é obrigatório ter o nome pt_BR com a extenção lang, ou seja pt_BR.lang

qualquer duvida, chamar no dicord: Purple-Senpai#2860
