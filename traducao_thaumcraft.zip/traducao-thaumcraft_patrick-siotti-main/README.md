# traducao-thaumcraft_patrick-siotti
tradução do mod thaumcraft6 para minecraft 1.12.x

eu gosto bastante do thaumcraft, e procurando uma tradução acabei achando uma bem bacana, porem estava com varios bugs, então modifiquei-a. 
Podem usar como bem preferirem, se caso for publicar em seu nome não será preciso deixar os créditos.

# como usar a tradução:

baixe a tradução

extraia ela e abra a pasta extraida

copie o arquivo pt_br

vá até o arquivo do mod, clique com o botão direito, ir té "abrir como", clicar em "winRar archive" ou só "WinRar"

abrir a pasta assets

abrir a pasta thaumcraft

abrir a pasta lang

então colar o arquivo da tradução

é obrigatório ter o nome pt_br com a extenção lang, ou seja pt_br.lang

qualquer duvida, chamar no dicord: Purple-Senpai#2860
