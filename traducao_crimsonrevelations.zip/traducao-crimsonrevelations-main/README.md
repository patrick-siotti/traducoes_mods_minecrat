# traducao-crimsonrevelations
tradução do mod crimsonrevelations para minecraft 1.12.x

eu gosto bastante do thaumcraft, então eu comecei a procurar adons ou mods que complementavam o thaumcraft, e procurando achei o crimsonrevelations, só q acabo ficando meio chato, ja que ele estava todo em ingles, e meu ingles é muito ruim, então traduzi-lo. Podem usar como bem preferirem, se caso for publicar em seu nome não será preciso deixar os créditos.

# como usar a tradução:

baixe a tradução

extraia ela e abra a pasta extraida

copie o arquivo pt_br

vá até o arquivo do mod, clique com o botão direito, ir té "abrir como", clicar em "winRar archive" ou só "WinRar"

abrir a pasta assets

abrir a pasta crimsonrevelations

abrir a pasta lang

então colar o arquivo da tradução

é obrigatório ter o nome pt_br com a extenção lang, ou seja pt_br.lang

pode ser que a tradução não esteja tão boa, caso aconteça algum erro ou alguma coisa esteja traduzida errado, é só chamar no dicord: Purple-Senpai#2860
